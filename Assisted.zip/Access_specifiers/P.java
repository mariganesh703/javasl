package Access_specifiers;


public class P extends N {

public static void main (String args[])
{
N ob=new N();
ob.printnoN();
M obj=new M();
obj.printno();
}

}
