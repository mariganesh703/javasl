package access2;

public class Class_X {
	private int a=10;
	long b=4;
	protected float c=6;
	char s='d';
	public void printnoX()
	{
		System.out.println(" "+a+" "+b+" "+c+" "+s);
	}
}
