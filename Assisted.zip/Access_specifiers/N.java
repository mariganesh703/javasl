package Access_specifiers;

public class N {
	private int k=10;
	long l=4;
	protected float m=6;
	public void printnoN()
	{
		System.out.println(" "+k+" "+l+" "+m);
	}
}
