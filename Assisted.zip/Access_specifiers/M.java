package Access_specifiers;

public class M {
	private int a=1;
	long b=25;
	protected float c=66;
	public void printno()
	{
		System.out.println(" "+a+" "+b+" "+c);
	}
}
